
function TwoFer({ name = "you" }) {
  return <p>One for {name}, one for me.</p>;
}

export default TwoFer;
