
declare module './TwoFer' {
    import { FunctionComponent } from 'react';
  
    const TwoFer: FunctionComponent<{ name?: string }>;
    export default TwoFer;
  }
  