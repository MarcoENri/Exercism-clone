import { FunctionComponent } from "react";

declare const TwoFer: FunctionComponent<{ name?: string }>;
export default TwoFer;
